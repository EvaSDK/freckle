--
-- PostgreSQL database dump
--

SET client_encoding = 'LATIN1';
SET check_function_bodies = false;

SET SESSION AUTHORIZATION 'postgres';

SET SESSION AUTHORIZATION 'eva';

SET search_path = public, pg_catalog;

DROP TABLE public.fichiers;
DROP TABLE public.reference;
DROP TABLE public.types;
DROP TABLE public.categorie;
SET SESSION AUTHORIZATION 'postgres';

--
-- TOC entry 4 (OID 2200)
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;
GRANT USAGE ON SCHEMA public TO reader;


SET SESSION AUTHORIZATION 'eva';

--
-- TOC entry 5 (OID 17498)
-- Name: categorie; Type: TABLE; Schema: public; Owner: eva
--

CREATE TABLE categorie (
    id serial NOT NULL,
    ccourt name,
    clong name
);


--
-- TOC entry 6 (OID 17498)
-- Name: categorie; Type: ACL; Schema: public; Owner: eva
--

REVOKE ALL ON TABLE categorie FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE categorie TO reader;


--
-- TOC entry 14 (OID 17498)
-- Name: categorie_id_seq; Type: ACL; Schema: public; Owner: eva
--

REVOKE ALL ON TABLE categorie_id_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE categorie_id_seq TO reader;


--
-- TOC entry 7 (OID 17520)
-- Name: types; Type: TABLE; Schema: public; Owner: eva
--

CREATE TABLE types (
    id serial NOT NULL,
    "type" name
);


--
-- TOC entry 8 (OID 17520)
-- Name: types; Type: ACL; Schema: public; Owner: eva
--

REVOKE ALL ON TABLE types FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE types TO reader;


--
-- TOC entry 16 (OID 17520)
-- Name: types_id_seq; Type: ACL; Schema: public; Owner: eva
--

REVOKE ALL ON TABLE types_id_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE types_id_seq TO reader;


--
-- TOC entry 9 (OID 17533)
-- Name: reference; Type: TABLE; Schema: public; Owner: eva
--

CREATE TABLE reference (
    id_categorie serial NOT NULL,
    id_fichier serial NOT NULL,
    id_type serial NOT NULL
);


--
-- TOC entry 10 (OID 17533)
-- Name: reference; Type: ACL; Schema: public; Owner: eva
--

REVOKE ALL ON TABLE reference FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE reference TO reader;


--
-- TOC entry 18 (OID 17533)
-- Name: reference_id_catgorie_seq; Type: ACL; Schema: public; Owner: eva
--

REVOKE ALL ON TABLE reference_id_catgorie_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE reference_id_catgorie_seq TO reader;


--
-- TOC entry 21 (OID 17533)
-- Name: reference_id_type_seq; Type: ACL; Schema: public; Owner: eva
--

REVOKE ALL ON TABLE reference_id_type_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE reference_id_type_seq TO reader;


--
-- TOC entry 11 (OID 27098)
-- Name: fichiers; Type: TABLE; Schema: public; Owner: eva
--

CREATE TABLE fichiers (
    id serial NOT NULL,
    url character varying,
    annee_prod integer,
    commentaire character varying
);


--
-- TOC entry 12 (OID 27098)
-- Name: fichiers; Type: ACL; Schema: public; Owner: eva
--

REVOKE ALL ON TABLE fichiers FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE fichiers TO reader;


--
-- TOC entry 23 (OID 27098)
-- Name: fichiers_id_seq; Type: ACL; Schema: public; Owner: eva
--

REVOKE ALL ON TABLE fichiers_id_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE fichiers_id_seq TO reader;


--
-- Data for TOC entry 24 (OID 17498)
-- Name: categorie; Type: TABLE DATA; Schema: public; Owner: eva
--

INSERT INTO categorie VALUES (1, 'I1', 'Ing�nieur premi�re ann�e');
INSERT INTO categorie VALUES (2, 'I2', 'Ing�nieur deuxi�me ann�e');
INSERT INTO categorie VALUES (3, 'I3', 'Ing�nieur troisi�me ann�e');
INSERT INTO categorie VALUES (4, 'I4', 'Ing�nieur quatri�me ann�e');
INSERT INTO categorie VALUES (5, 'I5', 'Ing�nieur cinqui�me ann�e');
INSERT INTO categorie VALUES (6, 'EL', 'Electronique');
INSERT INTO categorie VALUES (7, 'IN', 'Informatique');
INSERT INTO categorie VALUES (8, 'PH', 'Physique');
INSERT INTO categorie VALUES (9, 'MA', 'Math�matiques');
INSERT INTO categorie VALUES (10, 'EN', 'Anglais');
INSERT INTO categorie VALUES (11, 'SE', 'Majeure Syst�mes Embarqu�s');
INSERT INTO categorie VALUES (12, 'ST', 'Majeure T�l�communications');
INSERT INTO categorie VALUES (13, 'EM', 'Majeure Micro Electronique');
INSERT INTO categorie VALUES (14, 'IF', 'Majeure Informatique');


--
-- Data for TOC entry 25 (OID 17520)
-- Name: types; Type: TABLE DATA; Schema: public; Owner: eva
--

INSERT INTO types VALUES (1, 'Cours');
INSERT INTO types VALUES (2, 'Rapport de TP');
INSERT INTO types VALUES (3, 'TD');
INSERT INTO types VALUES (4, 'Notes');


--
-- Data for TOC entry 26 (OID 17533)
-- Name: reference; Type: TABLE DATA; Schema: public; Owner: eva
--

INSERT INTO reference VALUES (6, 1, 0);
INSERT INTO reference VALUES (2, 1, 0);
INSERT INTO reference VALUES (6, 2, 0);
INSERT INTO reference VALUES (2, 2, 0);
INSERT INTO reference VALUES (6, 3, 0);
INSERT INTO reference VALUES (2, 3, 0);
INSERT INTO reference VALUES (6, 4, 0);
INSERT INTO reference VALUES (2, 4, 0);
INSERT INTO reference VALUES (6, 5, 0);
INSERT INTO reference VALUES (2, 5, 0);
INSERT INTO reference VALUES (6, 6, 0);
INSERT INTO reference VALUES (2, 6, 0);
INSERT INTO reference VALUES (6, 7, 0);
INSERT INTO reference VALUES (2, 7, 0);
INSERT INTO reference VALUES (6, 8, 0);
INSERT INTO reference VALUES (2, 8, 0);
INSERT INTO reference VALUES (6, 9, 0);
INSERT INTO reference VALUES (2, 9, 0);
INSERT INTO reference VALUES (6, 10, 0);
INSERT INTO reference VALUES (2, 10, 0);
INSERT INTO reference VALUES (6, 11, 0);
INSERT INTO reference VALUES (2, 11, 0);
INSERT INTO reference VALUES (6, 12, 0);
INSERT INTO reference VALUES (2, 12, 0);
INSERT INTO reference VALUES (6, 13, 0);
INSERT INTO reference VALUES (3, 13, 0);
INSERT INTO reference VALUES (6, 14, 0);
INSERT INTO reference VALUES (4, 14, 0);
INSERT INTO reference VALUES (6, 15, 0);
INSERT INTO reference VALUES (4, 15, 0);
INSERT INTO reference VALUES (6, 16, 0);
INSERT INTO reference VALUES (4, 16, 0);
INSERT INTO reference VALUES (6, 17, 0);
INSERT INTO reference VALUES (4, 17, 0);
INSERT INTO reference VALUES (6, 18, 0);
INSERT INTO reference VALUES (4, 18, 0);
INSERT INTO reference VALUES (6, 19, 0);
INSERT INTO reference VALUES (4, 19, 0);
INSERT INTO reference VALUES (6, 20, 0);
INSERT INTO reference VALUES (4, 20, 0);
INSERT INTO reference VALUES (6, 21, 0);
INSERT INTO reference VALUES (4, 21, 0);
INSERT INTO reference VALUES (6, 22, 0);
INSERT INTO reference VALUES (4, 22, 0);
INSERT INTO reference VALUES (6, 23, 0);
INSERT INTO reference VALUES (4, 23, 0);
INSERT INTO reference VALUES (7, 24, 0);
INSERT INTO reference VALUES (1, 24, 0);
INSERT INTO reference VALUES (7, 25, 0);
INSERT INTO reference VALUES (1, 25, 0);
INSERT INTO reference VALUES (7, 26, 0);
INSERT INTO reference VALUES (1, 26, 0);
INSERT INTO reference VALUES (7, 27, 0);
INSERT INTO reference VALUES (1, 27, 0);
INSERT INTO reference VALUES (7, 28, 0);
INSERT INTO reference VALUES (2, 28, 0);
INSERT INTO reference VALUES (7, 29, 0);
INSERT INTO reference VALUES (2, 29, 0);
INSERT INTO reference VALUES (7, 30, 0);
INSERT INTO reference VALUES (2, 30, 0);
INSERT INTO reference VALUES (7, 31, 0);
INSERT INTO reference VALUES (2, 31, 0);
INSERT INTO reference VALUES (7, 32, 0);
INSERT INTO reference VALUES (2, 32, 0);
INSERT INTO reference VALUES (7, 33, 0);
INSERT INTO reference VALUES (2, 33, 0);
INSERT INTO reference VALUES (7, 34, 0);
INSERT INTO reference VALUES (2, 34, 0);
INSERT INTO reference VALUES (7, 35, 0);
INSERT INTO reference VALUES (2, 35, 0);
INSERT INTO reference VALUES (7, 36, 0);
INSERT INTO reference VALUES (2, 36, 0);
INSERT INTO reference VALUES (7, 37, 0);
INSERT INTO reference VALUES (2, 37, 0);
INSERT INTO reference VALUES (7, 38, 0);
INSERT INTO reference VALUES (2, 38, 0);
INSERT INTO reference VALUES (7, 39, 0);
INSERT INTO reference VALUES (2, 39, 0);
INSERT INTO reference VALUES (3, 39, 0);
INSERT INTO reference VALUES (7, 40, 0);
INSERT INTO reference VALUES (3, 40, 0);
INSERT INTO reference VALUES (7, 41, 0);
INSERT INTO reference VALUES (3, 41, 0);
INSERT INTO reference VALUES (7, 42, 0);
INSERT INTO reference VALUES (3, 42, 0);
INSERT INTO reference VALUES (7, 43, 0);
INSERT INTO reference VALUES (3, 43, 0);
INSERT INTO reference VALUES (7, 44, 0);
INSERT INTO reference VALUES (3, 44, 0);
INSERT INTO reference VALUES (7, 45, 0);
INSERT INTO reference VALUES (3, 45, 0);
INSERT INTO reference VALUES (7, 46, 0);
INSERT INTO reference VALUES (3, 46, 0);
INSERT INTO reference VALUES (7, 47, 0);
INSERT INTO reference VALUES (3, 47, 0);
INSERT INTO reference VALUES (7, 48, 0);
INSERT INTO reference VALUES (3, 48, 0);
INSERT INTO reference VALUES (7, 49, 0);
INSERT INTO reference VALUES (4, 49, 0);
INSERT INTO reference VALUES (7, 50, 0);
INSERT INTO reference VALUES (4, 50, 0);
INSERT INTO reference VALUES (7, 51, 0);
INSERT INTO reference VALUES (4, 51, 0);
INSERT INTO reference VALUES (7, 52, 0);
INSERT INTO reference VALUES (4, 52, 0);
INSERT INTO reference VALUES (7, 53, 0);
INSERT INTO reference VALUES (4, 53, 0);
INSERT INTO reference VALUES (7, 54, 0);
INSERT INTO reference VALUES (4, 54, 0);
INSERT INTO reference VALUES (7, 55, 0);
INSERT INTO reference VALUES (4, 55, 0);
INSERT INTO reference VALUES (7, 56, 0);
INSERT INTO reference VALUES (4, 56, 0);
INSERT INTO reference VALUES (7, 57, 0);
INSERT INTO reference VALUES (4, 57, 0);
INSERT INTO reference VALUES (7, 58, 0);
INSERT INTO reference VALUES (4, 58, 0);
INSERT INTO reference VALUES (7, 59, 0);
INSERT INTO reference VALUES (4, 59, 0);
INSERT INTO reference VALUES (7, 60, 0);
INSERT INTO reference VALUES (4, 60, 0);
INSERT INTO reference VALUES (7, 61, 0);
INSERT INTO reference VALUES (4, 61, 0);
INSERT INTO reference VALUES (7, 62, 0);
INSERT INTO reference VALUES (4, 62, 0);
INSERT INTO reference VALUES (7, 63, 0);
INSERT INTO reference VALUES (4, 63, 0);
INSERT INTO reference VALUES (7, 64, 0);
INSERT INTO reference VALUES (4, 64, 0);
INSERT INTO reference VALUES (7, 65, 0);
INSERT INTO reference VALUES (4, 65, 0);
INSERT INTO reference VALUES (7, 66, 0);
INSERT INTO reference VALUES (4, 66, 0);
INSERT INTO reference VALUES (7, 67, 0);
INSERT INTO reference VALUES (4, 67, 0);
INSERT INTO reference VALUES (7, 68, 0);
INSERT INTO reference VALUES (4, 68, 0);
INSERT INTO reference VALUES (7, 69, 0);
INSERT INTO reference VALUES (4, 69, 0);
INSERT INTO reference VALUES (7, 70, 0);
INSERT INTO reference VALUES (4, 70, 0);
INSERT INTO reference VALUES (7, 71, 0);
INSERT INTO reference VALUES (4, 71, 0);
INSERT INTO reference VALUES (7, 72, 0);
INSERT INTO reference VALUES (4, 72, 0);
INSERT INTO reference VALUES (7, 73, 0);
INSERT INTO reference VALUES (4, 73, 0);
INSERT INTO reference VALUES (7, 74, 0);
INSERT INTO reference VALUES (4, 74, 0);
INSERT INTO reference VALUES (7, 75, 0);
INSERT INTO reference VALUES (4, 75, 0);
INSERT INTO reference VALUES (8, 76, 0);
INSERT INTO reference VALUES (1, 76, 0);
INSERT INTO reference VALUES (8, 77, 0);
INSERT INTO reference VALUES (2, 77, 0);
INSERT INTO reference VALUES (8, 78, 0);
INSERT INTO reference VALUES (2, 78, 0);
INSERT INTO reference VALUES (8, 79, 0);
INSERT INTO reference VALUES (2, 79, 0);
INSERT INTO reference VALUES (8, 80, 0);
INSERT INTO reference VALUES (2, 80, 0);
INSERT INTO reference VALUES (8, 81, 0);
INSERT INTO reference VALUES (2, 81, 0);
INSERT INTO reference VALUES (8, 82, 0);
INSERT INTO reference VALUES (2, 82, 0);
INSERT INTO reference VALUES (8, 83, 0);
INSERT INTO reference VALUES (4, 83, 0);
INSERT INTO reference VALUES (9, 84, 0);
INSERT INTO reference VALUES (1, 84, 0);
INSERT INTO reference VALUES (9, 85, 0);
INSERT INTO reference VALUES (1, 85, 0);
INSERT INTO reference VALUES (9, 86, 0);
INSERT INTO reference VALUES (2, 86, 0);
INSERT INTO reference VALUES (9, 87, 0);
INSERT INTO reference VALUES (2, 87, 0);
INSERT INTO reference VALUES (9, 88, 0);
INSERT INTO reference VALUES (2, 88, 0);
INSERT INTO reference VALUES (9, 89, 0);
INSERT INTO reference VALUES (2, 89, 0);
INSERT INTO reference VALUES (9, 90, 0);
INSERT INTO reference VALUES (2, 90, 0);
INSERT INTO reference VALUES (9, 91, 0);
INSERT INTO reference VALUES (2, 91, 0);
INSERT INTO reference VALUES (9, 92, 0);
INSERT INTO reference VALUES (2, 92, 0);
INSERT INTO reference VALUES (9, 93, 0);
INSERT INTO reference VALUES (2, 93, 0);
INSERT INTO reference VALUES (9, 94, 0);
INSERT INTO reference VALUES (2, 94, 0);
INSERT INTO reference VALUES (9, 95, 0);
INSERT INTO reference VALUES (9, 96, 0);
INSERT INTO reference VALUES (4, 96, 0);
INSERT INTO reference VALUES (9, 97, 0);
INSERT INTO reference VALUES (4, 97, 0);
INSERT INTO reference VALUES (9, 98, 0);
INSERT INTO reference VALUES (4, 98, 0);
INSERT INTO reference VALUES (9, 99, 0);
INSERT INTO reference VALUES (4, 99, 0);
INSERT INTO reference VALUES (9, 100, 0);
INSERT INTO reference VALUES (4, 100, 0);
INSERT INTO reference VALUES (9, 101, 0);
INSERT INTO reference VALUES (4, 101, 0);
INSERT INTO reference VALUES (10, 102, 0);
INSERT INTO reference VALUES (3, 102, 0);
INSERT INTO reference VALUES (10, 103, 0);
INSERT INTO reference VALUES (3, 103, 0);
INSERT INTO reference VALUES (10, 104, 0);
INSERT INTO reference VALUES (3, 104, 0);
INSERT INTO reference VALUES (10, 105, 0);
INSERT INTO reference VALUES (3, 105, 0);
INSERT INTO reference VALUES (10, 106, 0);
INSERT INTO reference VALUES (4, 106, 0);
INSERT INTO reference VALUES (10, 107, 0);
INSERT INTO reference VALUES (4, 107, 0);
INSERT INTO reference VALUES (10, 108, 0);
INSERT INTO reference VALUES (4, 108, 0);
INSERT INTO reference VALUES (10, 109, 0);
INSERT INTO reference VALUES (4, 109, 0);
INSERT INTO reference VALUES (10, 110, 0);
INSERT INTO reference VALUES (4, 110, 0);


--
-- Data for TOC entry 27 (OID 27098)
-- Name: fichiers; Type: TABLE DATA; Schema: public; Owner: eva
--

INSERT INTO fichiers VALUES (1, 'EL/EL-202-cours_vhdl.pdf', 0, '');
INSERT INTO fichiers VALUES (2, 'EL/EL-202-ligne_trans_td1.zip', 0, '');
INSERT INTO fichiers VALUES (3, 'EL/EL-202-lignes.pdf', 0, '');
INSERT INTO fichiers VALUES (4, 'EL/EL-202-quadripoles.zip', 0, '');
INSERT INTO fichiers VALUES (5, 'EL/EL-202-source_tp_matlab.M.txt', 0, '');
INSERT INTO fichiers VALUES (6, 'EL/EL-202-sys_ass_td1.zip', 0, '');
INSERT INTO fichiers VALUES (7, 'EL/EL-202-sys_ass_td2.zip', 0, '');
INSERT INTO fichiers VALUES (8, 'EL/EL-202-vhdl_cookbook.pdf', 0, '');
INSERT INTO fichiers VALUES (9, 'EL/EL-202-vhdl_td1.zip', 0, '');
INSERT INTO fichiers VALUES (10, 'EL/EL-202-vhdl_td2.zip', 0, '');
INSERT INTO fichiers VALUES (11, 'EL/EL-202-vhdl_td3.zip', 0, '');
INSERT INTO fichiers VALUES (12, 'EL/EL-213-td1.rar', 0, '');
INSERT INTO fichiers VALUES (13, 'EL/EL-3xx-g_signal_rapport_tp.doc', 0, '');
INSERT INTO fichiers VALUES (14, 'EL/EL-411-additionneur_bcd.zip', 0, '');
INSERT INTO fichiers VALUES (15, 'EL/EL-411-corr_controle.pdf', 0, '');
INSERT INTO fichiers VALUES (16, 'EL/EL-411-document.pdf', 0, '');
INSERT INTO fichiers VALUES (17, 'EL/EL-411-rapport_projet.doc', 0, '');
INSERT INTO fichiers VALUES (18, 'EL/EL-411-reseaux_test.pdf', 0, '');
INSERT INTO fichiers VALUES (19, 'EL/EL-411-tp_synth.rar', 0, '');
INSERT INTO fichiers VALUES (20, 'EL/EL-411-vhdl_proj.zip', 0, '');
INSERT INTO fichiers VALUES (21, 'EL/EL-413-document_2.pdf', 0, '');
INSERT INTO fichiers VALUES (22, 'EL/EL-413-td.pdf', 0, '');
INSERT INTO fichiers VALUES (23, 'EL/EL-413-tp.rar', 0, '');
INSERT INTO fichiers VALUES (24, 'IN/IN-102-rapport_TP1.tgz', 0, '');
INSERT INTO fichiers VALUES (25, 'IN/IN-102-rapport_TP2.doc', 0, '');
INSERT INTO fichiers VALUES (26, 'IN/IN-102-rapport_TP3_TP4.tgz', 0, '');
INSERT INTO fichiers VALUES (27, 'IN/IN-102-tp_pia.doc', 0, '');
INSERT INTO fichiers VALUES (28, 'IN/IN-201-mini_projet.s.txt', 0, '');
INSERT INTO fichiers VALUES (29, 'IN/IN-202-cours.pdf', 0, '');
INSERT INTO fichiers VALUES (30, 'IN/IN-202-sujet_tp123.zip', 0, '');
INSERT INTO fichiers VALUES (31, 'IN/IN-202-td1.zip', 0, '');
INSERT INTO fichiers VALUES (32, 'IN/IN-202-tp1.doc', 0, '');
INSERT INTO fichiers VALUES (33, 'IN/IN-202-tp1.pdf', 0, '');
INSERT INTO fichiers VALUES (34, 'IN/IN-202-tp1_tripartas.pdf', 0, '');
INSERT INTO fichiers VALUES (35, 'IN/IN-202-tp2.doc', 0, '');
INSERT INTO fichiers VALUES (36, 'IN/IN-202-tp2.pdf', 0, '');
INSERT INTO fichiers VALUES (37, 'IN/IN-202-tp2_algo.doc', 0, '');
INSERT INTO fichiers VALUES (38, 'IN/IN-202-tp3.pdf', 0, '');
INSERT INTO fichiers VALUES (39, 'IN/IN-202.302.311-cours_algo.pdf', 0, '');
INSERT INTO fichiers VALUES (40, 'IN/IN-301-rapport_tp1.pdf', 0, '');
INSERT INTO fichiers VALUES (41, 'IN/IN-301-rapport_tp1_.pdf', 0, '');
INSERT INTO fichiers VALUES (42, 'IN/IN-301-rapport_tp2.pdf', 0, '');
INSERT INTO fichiers VALUES (43, 'IN/IN-301-rapport_tp2_.pdf', 0, '');
INSERT INTO fichiers VALUES (44, 'IN/IN-301-rapport_tp3.pdf', 0, '');
INSERT INTO fichiers VALUES (45, 'IN/IN-301-rapport_tp4.pdf', 0, '');
INSERT INTO fichiers VALUES (46, 'IN/IN-301-rapport_tp5.pdf', 0, '');
INSERT INTO fichiers VALUES (47, 'IN/IN-301-rapport_tp6.pdf', 0, '');
INSERT INTO fichiers VALUES (48, 'IN/IN-3xx-rapport_tp1-tp2.doc', 0, '');
INSERT INTO fichiers VALUES (49, 'IN/IN-411-tp.zip', 0, '');
INSERT INTO fichiers VALUES (50, 'IN/IN-411-tp1.doc', 0, '');
INSERT INTO fichiers VALUES (51, 'IN/IN-411-tp1_tp2.pdf', 0, '');
INSERT INTO fichiers VALUES (52, 'IN/IN-411-tp1_tp2_.pdf', 0, '');
INSERT INTO fichiers VALUES (53, 'IN/IN-411-tp1_tp2__.pdf', 0, '');
INSERT INTO fichiers VALUES (54, 'IN/IN-411-tp2.doc', 0, '');
INSERT INTO fichiers VALUES (55, 'IN/IN-411-tp_2003.doc', 0, '');
INSERT INTO fichiers VALUES (56, 'IN/IN-412-introduction_rt.ppt', 0, '');
INSERT INTO fichiers VALUES (57, 'IN/IN-412-ordonencement.ppt', 0, '');
INSERT INTO fichiers VALUES (58, 'IN/IN-412-ordonencement.rar', 0, '');
INSERT INTO fichiers VALUES (59, 'IN/IN-412-projet_mini_processeur.zip', 0, '');
INSERT INTO fichiers VALUES (60, 'IN/IN-412-rt1.doc', 0, '');
INSERT INTO fichiers VALUES (61, 'IN/IN-412-rt2.doc', 0, '');
INSERT INTO fichiers VALUES (62, 'IN/IN-412-rtlinux.ppt', 0, '');
INSERT INTO fichiers VALUES (63, 'IN/IN-412-tp1.doc', 0, '');
INSERT INTO fichiers VALUES (64, 'IN/IN-412-tp1_tp2.zip', 0, '');
INSERT INTO fichiers VALUES (65, 'IN/IN-412-tp2.doc', 0, '');
INSERT INTO fichiers VALUES (66, 'IN/IN-412-tp2.pdf', 0, '');
INSERT INTO fichiers VALUES (67, 'IN/IN-412-tp2.rar', 0, '');
INSERT INTO fichiers VALUES (68, 'IN/IN-413-devoir.rar', 0, '');
INSERT INTO fichiers VALUES (69, 'IN/IN-413-java-tp1234567.zip', 0, '');
INSERT INTO fichiers VALUES (70, 'IN/IN-413-java_partie_1.pdf', 0, '');
INSERT INTO fichiers VALUES (71, 'IN/IN-413-java_partie_2.pdf', 0, '');
INSERT INTO fichiers VALUES (72, 'IN/IN-413-rapports_java.zip', 0, '');
INSERT INTO fichiers VALUES (73, 'IN/IN-413-tp.zip', 0, '');
INSERT INTO fichiers VALUES (74, 'IN/IN-413-tp4.rar', 0, '');
INSERT INTO fichiers VALUES (75, 'IN/IN-413-tp6.rar', 0, '');
INSERT INTO fichiers VALUES (76, 'PH/PH-101-cours.doc', 0, '');
INSERT INTO fichiers VALUES (77, 'PH/PH-202-fiches.tgz', 0, '');
INSERT INTO fichiers VALUES (78, 'PH/PH-202-td1.zip', 0, '');
INSERT INTO fichiers VALUES (79, 'PH/PH-202-td2.zip', 0, '');
INSERT INTO fichiers VALUES (80, 'PH/PH-202-td3.zip', 0, '');
INSERT INTO fichiers VALUES (81, 'PH/PH-202-td4.zip', 0, '');
INSERT INTO fichiers VALUES (82, 'PH/PH-202-td5.zip', 0, '');
INSERT INTO fichiers VALUES (83, 'PH/PH-412-optique.pdf', 0, '');
INSERT INTO fichiers VALUES (84, 'MA/MA-102-mathematica_1.nb.txt', 0, '');
INSERT INTO fichiers VALUES (85, 'MA/MA-103-cours_espaces_vectoriels.tgz', 0, '');
INSERT INTO fichiers VALUES (86, 'MA/MA-202-fiches.zip', 0, '');
INSERT INTO fichiers VALUES (87, 'MA/MA-202-td1.zip', 0, '');
INSERT INTO fichiers VALUES (88, 'MA/MA-202-td2.zip', 0, '');
INSERT INTO fichiers VALUES (89, 'MA/MA-202-td2_bis.zip', 0, '');
INSERT INTO fichiers VALUES (90, 'MA/MA-202-td3.zip', 0, '');
INSERT INTO fichiers VALUES (91, 'MA/MA-202-td4.zip', 0, '');
INSERT INTO fichiers VALUES (92, 'MA/MA-202-td5.zip', 0, '');
INSERT INTO fichiers VALUES (93, 'MA/MA-202-td6.zip', 0, '');
INSERT INTO fichiers VALUES (94, 'MA/MA-202-td7.zip', 0, '');
INSERT INTO fichiers VALUES (95, 'MA/MA-30x-proba.zip', 0, '');
INSERT INTO fichiers VALUES (96, 'MA/MA-412-TDI_1.rar', 0, '');
INSERT INTO fichiers VALUES (97, 'MA/MA-412-TDI_2.rar', 0, '');
INSERT INTO fichiers VALUES (98, 'MA/MA-412-TDI_3.rar', 0, '');
INSERT INTO fichiers VALUES (99, 'MA/MA-412-rapport_tp1.doc', 0, '');
INSERT INTO fichiers VALUES (100, 'MA/MA-412-rapport_tp1_tp3.zip', 0, '');
INSERT INTO fichiers VALUES (101, 'MA/MA-412-rapport_tp3.doc', 0, '');
INSERT INTO fichiers VALUES (102, 'EN/EN-302-rapport_E6.doc', 0, '');
INSERT INTO fichiers VALUES (103, 'EN/EN-3xx-AutonomousLearningReport.doc', 0, '');
INSERT INTO fichiers VALUES (104, 'EN/EN-3xx-E6_final_draft_business_ethics_on.doc', 0, '');
INSERT INTO fichiers VALUES (105, 'EN/EN-3xx-research_paper.doc', 0, '');
INSERT INTO fichiers VALUES (106, 'EN/EN-4xx-CV_howto_by_Todman.pdf', 0, '');
INSERT INTO fichiers VALUES (107, 'EN/EN-4xx-CV_letter.zip', 0, '');
INSERT INTO fichiers VALUES (108, 'EN/EN-4xx-pop_L5_story.doc', 0, '');
INSERT INTO fichiers VALUES (109, 'EN/EN-4xx-rock_is_the_music.doc', 0, '');
INSERT INTO fichiers VALUES (110, 'EN/EN-4xx-rock_john_lennon.zip', 0, '');
INSERT INTO fichiers VALUES (111, 'Majeur/EM/EM4-CINU-FrontEndJPEG.zip', 2004, 'test de fichiers ajout�s');


--
-- TOC entry 13 (OID 17496)
-- Name: categorie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: eva
--

SELECT pg_catalog.setval('categorie_id_seq', 14, true);


--
-- TOC entry 15 (OID 17518)
-- Name: types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: eva
--

SELECT pg_catalog.setval('types_id_seq', 16, true);


--
-- TOC entry 17 (OID 17527)
-- Name: reference_id_catgorie_seq; Type: SEQUENCE SET; Schema: public; Owner: eva
--

SELECT pg_catalog.setval('reference_id_catgorie_seq', 1, false);


--
-- TOC entry 19 (OID 17529)
-- Name: reference_id_fichier_seq; Type: SEQUENCE SET; Schema: public; Owner: eva
--

SELECT pg_catalog.setval('reference_id_fichier_seq', 1, false);


--
-- TOC entry 20 (OID 17531)
-- Name: reference_id_type_seq; Type: SEQUENCE SET; Schema: public; Owner: eva
--

SELECT pg_catalog.setval('reference_id_type_seq', 1, false);


--
-- TOC entry 22 (OID 27096)
-- Name: fichiers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: eva
--

SELECT pg_catalog.setval('fichiers_id_seq', 111, true);


SET SESSION AUTHORIZATION 'postgres';

--
-- TOC entry 3 (OID 2200)
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public schema';


